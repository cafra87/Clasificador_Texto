# -*- coding: utf-8 -*-
"""
Created on Fri Sep 19 16:32:55 2025
@author: LENOVO
"""

import streamlit as st
import os
import json
import requests

import numpy as np
import readability
import syntok.segmenter as segmenter


#Configuración de la página
st.set_page_config(page_title="Clasificador de Textos Médicos", layout="wide")

#Variables de entorno dos endpoints una para el clasificador y otra para el generador del pls si es clasificado como tecnico
API_URL = os.environ.get("API_URL", "http://localhost:5001/invocations")           # Clasificador
API_URL_PLS = os.environ.get("API_URL_PLS", "http://localhost:5002/invocations")   # Generador PLS

#Estado de la sesión
if "contador_sencillo" not in st.session_state:
    st.session_state.contador_sencillo = 0
if "contador_tecnico" not in st.session_state:
    st.session_state.contador_tecnico = 0
if "textos_sencillos" not in st.session_state:
    st.session_state.textos_sencillos = []
if "textos_tecnicos" not in st.session_state:
    st.session_state.textos_tecnicos = []
if "resultado" not in st.session_state:
    st.session_state.resultado = "(sin clasificar)"
if "pls_generado" not in st.session_state:
    st.session_state.pls_generado = ""

# para legibilidad del último PLS generado
if "readability_metrics" not in st.session_state:
    st.session_state.readability_metrics = None

#usamos una versión para recrear el widget al limpiar
if "input_version" not in st.session_state:
    st.session_state.input_version = 0

# Configuración legibilidad
READABILITY_METRICS = [
    "Coleman-Liau",
    "FleschReadingEase",
    "GunningFogIndex",
    "SMOGIndex",
    "Kincaid",
    "DaleChallIndex",
]


def calculate_readability_metrics(text: str):
    """
    Funcion para calcular métricas de legibilidad
    """
    results = {metric: np.nan for metric in READABILITY_METRICS}
    
    if not isinstance(text, str) or not text.strip():
        return results

    try:
        tokenized = '\n\n'.join(
            '\n'.join(
                ' '.join(token.value for token in sentence)
                for sentence in paragraph
            )
            for paragraph in segmenter.analyze(text)
        )

        measures = readability.getmeasures(tokenized, lang='en')
        grades = measures.get('readability grades')

        if grades:
            for metric in READABILITY_METRICS:
                if metric in grades:
                    results[metric] = round(grades[metric], 3)

        return results
    except Exception as e:
        # si algo falla, lo ves en los logs de ECS
        print("Error en calculate_readability_metrics:", e)
        return results

def format_metric(value):
    """
    Helper para mostrar las métricas de forma amigable en la UI.
    """
    if value is None:
        return "N/A"
    if isinstance(value, float) and np.isnan(value):
        return "N/A"
    return f"{value:.2f}"

#Utilidades:
def limpiar_texto():
    st.session_state.resultado = "(sin clasificar)"
    st.session_state.pls_generado = ""
    st.session_state.readability_metrics = None
    st.session_state.input_version += 1  # fuerza nuevo key → textarea vacío

def invocar_api_clasificador(texto: str):
    """
    Envia {"inputs": ["<texto>"]} al clasificador (MLflow) y devuelve (json_respuesta, error)
    """
    headers = {"Content-Type": "application/json"}
    payload = {"inputs": [texto]}
    try:
        r = requests.post(API_URL, headers=headers, data=json.dumps(payload), timeout=60)
        r.raise_for_status()
        return r.json(), None
    except requests.RequestException as e:
        return None, str(e)

def invocar_api_pls(texto: str):
    """
    Envia {"inputs": "<texto>"} al generador PLS (FastAPI) y devuelve (json_respuesta, error)
    """
    headers = {"Content-Type": "application/json"}
    payload = {"inputs": texto}
    try:
        r = requests.post(API_URL_PLS, headers=headers, data=json.dumps(payload), timeout=3600)
        r.raise_for_status()
        return r.json(), None
    except requests.RequestException as e:
        return None, str(e)

#forma:
col1, col2 = st.columns([1, 3])

with col1:
    st.markdown("## Clasificador de textos médicos")
    st.caption(f"Clasificador: `{API_URL}`")
    st.caption(f"Generador PLS: `{API_URL_PLS}`")

    #Tarjeta: Texto sencillo
    st.markdown(f"""
    <div style="border:1px solid #ccc; border-radius:10px; padding:15px; margin-bottom:10px; 
                box-shadow:2px 2px 5px rgba(0,0,0,0.08); display:flex; justify-content:space-between; align-items:center;">
        <h4 style="margin:0;">📋 Texto sencillo</h4>
        <span style="font-size:18px; font-weight:bold;">{st.session_state.contador_sencillo}</span>
    </div>
    """, unsafe_allow_html=True)

    #Tarjeta: Texto técnico
    st.markdown(f"""
    <div style="border:1px solid #ccc; border-radius:10px; padding:15px; margin-top:10px; margin-bottom:10px; 
                box-shadow:2px 2px 5px rgba(0,0,0,0.08); display:flex; justify-content:space-between; align-items:center;">
        <h4 style="margin:0;">💡 Texto técnico</h4>
        <span style="font-size:18px; font-weight:bold;">{st.session_state.contador_tecnico}</span>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("**Texto clasificado como:**")
    st.info(st.session_state.resultado)

    if st.session_state.pls_generado:
        st.markdown("**PLS generado (resumen en lenguaje sencillo):**")
        st.success(st.session_state.pls_generado)

        # Métricas de legibilidad del PLS
        if st.session_state.readability_metrics is not None:
            st.markdown("**Métricas de legibilidad del PLS:**")
            # Mostrar como lista simple
            for metric_name, value in st.session_state.readability_metrics.items():
                st.write(f"- {metric_name}: {value}")

    #Listados plegables de los textos clasificados
    if st.session_state.textos_sencillos:
        with st.expander("Ver textos sencillos"):
            for i, t in enumerate(st.session_state.textos_sencillos, 1):
                st.write(f"**{i}.** {t}")
    if st.session_state.textos_tecnicos:
        with st.expander("Ver textos técnicos"):
            for i, t in enumerate(st.session_state.textos_tecnicos, 1):
                st.write(f"**{i}.** {t}")

with col2:
    st.markdown("### Ingrese el texto")
    user_text = st.text_area(
        "Escriba o pegue aquí el texto a analizar...",
        height=350,
        key=f"user_text_input_{st.session_state.input_version}"
    )

    cA, cB = st.columns([2,1])
    with cA:
        enviar = st.button("🔎 Clasificar texto", use_container_width=True)
    with cB:
        st.button("🧹 Limpiar", use_container_width=True, on_click=limpiar_texto)

    #Lógica al enviar
    if enviar:
        st.session_state.pls_generado = ""  # limpiar PLS anterior
        if not user_text or not user_text.strip():
            st.warning("Por favor, ingrese un texto antes de analizar.")
        else:
            with st.spinner("Consultando API de clasificación..."):
                data, err = invocar_api_clasificador(user_text)

            if err:
                st.error(f"Error llamando a la API de clasificación: {err}")
            else:
                st.success(" Clasificación recibida")

                #para seguir viendo el JSON del clasificador
                st.subheader("Respuesta de la API (JSON - clasificador)")
                st.json(data)

                pred = None
                if isinstance(data, dict) and "predictions" in data:
                    preds = data["predictions"]
                    if isinstance(preds, list) and len(preds) > 0:
                        pred = preds[0]

                if pred is None:
                    st.warning("No encontré `predictions[0]` en la respuesta del clasificador.")
                else:
                    if pred == 1:
                        #TEXTO SENCILLO
                        st.session_state.resultado = "Texto sencillo"
                        st.session_state.contador_sencillo += 1
                        st.session_state.textos_sencillos.append(user_text)

                        #Mostramos la clasificación de una vez
                        st.info("**Clasificación:** Texto sencillo")

                    else:
                        #TEXTO TÉCNICO
                        st.session_state.resultado = "Texto técnico"
                        st.session_state.contador_tecnico += 1
                        st.session_state.textos_tecnicos.append(user_text)

                        #Esta frase se muestra ANTES de generar el PLS
                        st.info("**Clasificación:** Texto técnico")

                        #Llamamos automáticamente al generador PLS si es técnico
                        with st.spinner("Generando PLS (resumen en lenguaje sencillo)..."):
                            out, err2 = invocar_api_pls(user_text)

                        if err2:
                            st.error(f"Error llamando a la API PLS: {err2}")
                        else:
                            st.subheader("Respuesta de la API (JSON - generador PLS)")
                            st.json(out)

                            
                            summary = ""
                            if isinstance(out, dict):
                                if "summary" in out:
                                    summary = out["summary"]
                                elif "generated_summary" in out:
                                    summary = out["generated_summary"]

                            if summary:
                                st.session_state.pls_generado = summary
                                # calculamos y guardamos las métricas de legibilidad
                                # 🔍 Calculamos y mostramos métricas de legibilidad del PLS generado
                                with st.spinner("Calculando métricas de legibilidad del PLS..."):
                                    metrics = calculate_readability_metrics(summary)

                                st.session_state.readability_metrics = metrics

                                st.markdown("### Métricas de legibilidad del PLS generado")

                                colA, colB, colC = st.columns(3)

                                with colA:
                                    st.metric("Flesch Reading Ease", format_metric(metrics["FleschReadingEase"]))
                                    st.metric("Kincaid (grado escolar)", format_metric(metrics["Kincaid"]))

                                with colB:
                                    st.metric("Coleman-Liau (grado)", format_metric(metrics["Coleman-Liau"]))
                                    st.metric("Gunning Fog (grado)", format_metric(metrics["GunningFogIndex"]))

                                with colC:
                                    st.metric("SMOG (grado)", format_metric(metrics["SMOGIndex"]))
                                    st.metric("Dale-Chall (grado)", format_metric(metrics["DaleChallIndex"]))
                            else:
                                st.warning("La respuesta PLS no contiene 'summary' ni 'generated_summary'.")